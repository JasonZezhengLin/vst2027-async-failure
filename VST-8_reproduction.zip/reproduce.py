from pathlib import Path
import collections,json,os,shutil,subprocess,sys
R=Path(__file__).resolve().parent;node=os.environ.get('NODE_BINARY') or shutil.which('node');assert node,'Node.js 24 is required';files=json.loads((R/'data/virtual_runtime.json').read_text());rows=json.loads((R/'data/selected_executions.json').read_text());program=(R/'code/selected_runner.js').read_text();O=R/'reproduced';O.mkdir(exist_ok=False)
def execute(program,spec):
 p=subprocess.run([node,'--max-old-space-size=256','-e',program],input=json.dumps(spec),capture_output=True,text=True,timeout=15);marker='__VST_RUNNER_RESULT__';result=json.loads(p.stdout.rsplit(marker,1)[1].splitlines()[0]) if marker in p.stdout else None;ok=p.returncode==0 and 'AssertionError' not in p.stderr and result is not None and result['failures']==0
 verdict='PASSED' if ok and result['stats']['passes']==1 else 'PENDING' if ok and result['stats']['pending']==1 else 'FAILED';return {'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'runner_result':result,'verdict':verdict}
results=[];masked=[];eligible=[]
for row in rows:
 observed=[]
 for old in row['runs']:
  spec={'source':row['source'],'virtualFiles':dict(files),'injectFail':old['mode']=='forced_sink','exitImmediately':True};v=execute(program,spec);assert v['verdict']==old['validator_verdict'],(row['package'],row['test'],old['mode'],v['verdict'],old['validator_verdict']);observed.append({'mode':old['mode'],**v})
 baseline=all(v['verdict']=='PASSED' for v in observed[:3]);assert baseline==row['baseline_three_pass'];is_old=row['original_report_status']=='PASSED'
 if baseline and is_old:eligible.append(row)
 forced=observed[-1];tracker=(forced['runner_result'] or {}).get('assertionTracker',{'forced':0})
 if baseline and is_old and tracker['forced']>0 and forced['verdict']=='PASSED':masked.append((row['package'],row['test']))
 results.append({'package':row['package'],'test':row['test'],'runs':observed})
 assert len(observed)==4
assert len(rows)==60 and len(eligible)==23 and sum(not x['original_isTrivial'] for x in eligible)==17 and masked==[('bluebird','test_9.js')]
minimal=[]
for case in json.loads((R/'data/minimal_cases.json').read_text()):
 v=execute((R/'code/minimal_runner.js').read_text(),{'source':case['source'],'virtualFiles':dict(files),'exitImmediately':case['exitImmediately']});assert v['verdict']==case['validator_verdict_using_original_rules'],(case['case'],v['verdict']);minimal.append({'case':case['case'],**v})
report=json.loads((R/'data/historical_coverage.json').read_text());nt=[x for x in report['tests'] if x['status']=='PASSED' and not x['isTrivial']]
def union(xs):return set().union(*(set(x['coveredStatements']) for x in xs))
u=union(nt);u9=union([x for x in nt if x['testName']!='test_9.js']);u915=union([x for x in nt if x['testName'] not in ['test_9.js','test_15.js']]);assert len(nt)==133 and len(u)==len(u9)==len(u915)==2035 and u==u9==u915
(O/'selected_native_outputs.json').write_text(json.dumps(results,indent=2)+'\n');(O/'minimal_native_outputs.json').write_text(json.dumps(minimal,indent=2)+'\n');(O/'coverage.json').write_text(json.dumps({'original':len(u),'remove9':len(u9),'remove9and15':len(u915),'lost':[]},indent=2)+'\n');print(json.dumps({'result':'PASS','selected_tests':60,'native_children':240,'minimal_pair_children':len(minimal),'eligible_original_passes':23,'confirmed_masked_assertion_witnesses':1,'historical_coverage_union':2035}),flush=True)
